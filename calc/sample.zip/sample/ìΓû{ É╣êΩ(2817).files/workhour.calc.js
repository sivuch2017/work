$(document).ready(function() {
    $('#curDate').datepicker({minDate: '-3m', maxDate: '+3m'});
    var msg = "";

    $("#input").click(function() {
    	return validate();
    });

    $("#inputWorkhour").click(function() {
    	return validateWorkhour();
    });

    $("#holidayInput").click(function() {
	var ret = validateWorkTime("#startTimes", "#endTimes", ".overtimeHourAndHolydayReq");
	if (!ret) {
	    return ret;
	}
    	return validateWorkhour();
    });

    function validate() {
        msg = "";
        // 実績入力入力チェック
	$(".workhourtable").each(function() {
		// 色を元に戻す。
		$(this).find("input").css("background-color", "");

		var o_ws = $("#startTime", this);
		var o_we = $("#endTime", this);

                var FORMAT_ERROR = "入力した時刻形式が不正です。";
		// 時刻のフォーマットチェック
                if (validateFormat(o_ws.val()) == false) {
		        msg = FORMAT_ERROR;
                	setBg(o_ws);
		}
                if (validateFormat(o_we.val()) == false) {
		        msg = FORMAT_ERROR;
                	setBg(o_we);
		}
                // 片方だけ未入力の場合はエラー
                if (o_ws.val() != "" && o_we.val() == "") {
		        msg = FORMAT_ERROR;
                	setBg(o_we);
                } else if (o_ws.val() == "" && o_we.val() != "") {
		        msg = FORMAT_ERROR;
                	setBg(o_ws);
                }
	});

	$("#errmsg").children().remove();
		
	if (msg == "") {
		return true;
	} else {
		$("#errmsg").append("<div>" + msg + "</div>");
		$("#errmsg").css("color", "red");
		return false;
	}
    }

    function validateWorkhour() {
        msg = "";
        // 残業、休暇申請入力チェック
	$(".overtimeHourAndHolydayReq").each(function() {
		// 色を元に戻す。
		$(this).find("input").css("background-color", "");

		var o_dayKbn = $("#dayKbn", this);
		var o_curDay = $("#curDay", this);
		var o_memberName = $("#memberName", this);
		var o_workType = $("#workType", this);
		var o_dayOffReason = $("#dayOffReason", this);
		
		// 日付(MM)正規表現
	        var regExpMM = /(^0[1-9]|^[1-2][0-9]|^3[0-1])/;
		// メッセージプレフィックス
		var pref = o_memberName.val() + "：";

		// カンマ入力チェック
		if (o_dayOffReason.val().indexOf(",") >= 0) {
                    msg += pref + "休暇理由にカンマ(,)は入力できません。<BR>";
		    setBg(o_dayOffReason);
		}

		// 振休形式チェック
                if (o_workType.val() == "5") {
                	var FURIKYU_ERROR_01 = "振休先日付は01-31の間で指定して下さい。(振休/代休いずれも当月内のみ指定可能です)";
			if (o_dayOffReason.val().length != 2
				|| !regExpMM.test(o_dayOffReason.val())) {
				msg += pref + FURIKYU_ERROR_01 + "<BR>";
				setBg(o_dayOffReason);
			}
                }

                // 代休形式チェック
                if (o_workType.val() == "2") {
                	// 休日に入力しているかどうかのチェック
			if (o_dayKbn.val() == "00") {
                		msg += pref + "代休は平日に対しては申請できません。休日作業した日付に対して申請して下さい。";
				setBg(o_workType);
			} else {
				var ret = validateDaiKyu(o_dayOffReason.val(), o_curDay.val());
				if (ret != "") {
					msg += pref + ret + "<BR>";
					setBg(o_dayOffReason);
				}
			}
                }
	});

	$("#errmsg").children().remove();
		
	if (msg == "") {
		return true;
	} else {
		$("#errmsg").append("<div>" + msg + "</div>");
		$("#errmsg").css("color", "red");
		return false;
	}
    }

    function setBg(o) {
	o.css("background-color", "red");
    }

    function validateFormat(val) {
	// 未入力、または1の場合はチェックOK
	if (val == "1" || val == "") {
		return true;
	}
	// 時刻形式のチェック
	var regExp = /^[0-2][0-9][0-5][0-9][0-5][0-9]/;
	if (!regExp.test(val)) {
		return false;
	} else {
		if (val <= "235959") {
			return true;
		} else {
			return false;
		}
	}
    }

    function validateWorkTime(startName, endName, targetName) {
        msg = "";
        // 実績入力入力チェック
	$(targetName).each(function() {
		// 色を元に戻す。
		$(this).find("input").css("background-color", "");

		var o_ws = $(startName, this);
		var o_we = $(endName, this);
		var o_memberName = $("#memberName", this);

                var FORMAT_ERROR = "入力した時刻形式が不正です。";
		var buf = "";
		// 時刻のフォーマットチェック
                if (validateFormat(o_ws.val()) == false) {
		        buf = FORMAT_ERROR;
                	setBg(o_ws);
		}
                if (validateFormat(o_we.val()) == false) {
		        buf = FORMAT_ERROR;
                	setBg(o_we);
		}
                // 片方だけ未入力の場合はエラー
                if (o_ws.val() != "" && o_we.val() == "") {
		        buf = FORMAT_ERROR;
                	setBg(o_we);
                } else if (o_ws.val() == "" && o_we.val() != "") {
		        buf = FORMAT_ERROR;
                	setBg(o_ws);
                }

		if (buf != "") {
		    msg += o_memberName.val() + "：" + buf + "<br>";
		}
	});

	$("#errmsg").children().remove();
		
	if (msg == "") {
		return true;
	} else {
		$("#errmsg").append("<div>" + msg + "</div>");
		$("#errmsg").css("color", "red");
		return false;
	}
    }

});

function formatTime(val) {
	if (isEmpty(val)) {
		return val;
	}
	if (val.length != 5) {
		return "0" + val;
	}
	return val;
}

function isEmpty(val) {
	if (val == "") {
		return true;
	}
	return false;
}

function isTime(s) {
	var m = s.match(/^[0-2]?[0-9]:(00|15|30|45)$/);
	return (m != null) ? true : false;
}

function validateDaiKyu(val, curDay) {
	// 代休入力形式チェック(MM/x.xx)
	var DAIKYU_ERROR_01 = "<BR>代休先日付はMM/X.XXの形式で指定して下さい。<BR>(MM･･･代休先日付　X.XX･･･代休時間　例：25/7.50)<BR>※振休/代休いずれも当月内のみ指定可能です。";

	// 1) スラッシュ入っているか
	if (!val.match(/\//)) {
		return DAIKYU_ERROR_01;
	}

	// 2) スラッシュで分割
	var token = val.split("/");
	var mm = token[0];
	var time = token[1];

	var DAIKYU_ERROR_02 = "<BR>代休先日付(MM)は01-31の間で指定して下さい。";
	// 日付(MM)正規表現
	var regExpMM = /(^0[1-9]|^[1-2][0-9]|^3[0-1])/;
	// 3) MMのチェック
	if (mm.length != 2
		|| !regExpMM.test(val)) {
		return DAIKYU_ERROR_02;
	}

	var DAIKYU_ERROR_021 = "<BR>代休先日付(MM)は代休日の翌日以降の日付を指定して下さい。";
        if (mm <= curDay) {
		return DAIKYU_ERROR_021;
        }

	var DAIKYU_ERROR_03 = "<BR>代休時間(X.XX形式)は0.25 - 7.50の間で指定して下さい。<BR>丸一日代休の場合は7.50を入力して下さい。";
	// 4) timeのチェック
	var regExphm = /^(0.(25|50|75)|[1-7].(00|25|50|75))$/;
	if (!regExphm.test(time)) {
		return DAIKYU_ERROR_03;
	}

	 return "";
}

